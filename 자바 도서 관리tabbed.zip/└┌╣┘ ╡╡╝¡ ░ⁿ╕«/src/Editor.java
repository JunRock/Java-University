import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.StringTokenizer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

class Editorpanel extends JPanel{
	 File f = new File("C:\\Temp\\Book.txt");
     BufferedReader br = null;
     BufferedReader br2 = null;
     FileReader fr = null;
     JTextField insert=new JTextField();
     private JTable table;
     
     int n = 0;

	public Editorpanel() {
		//JPanel editor=new JPanel();
		setLayout(null);
		 try {
	         fr = new FileReader(f);
	         br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
	         String readLine = null;
	         
	         while((readLine=br.readLine())!=null) {   
	            n++;
	         }  
		 }
	         catch(IOException e) {
	        	 e.printStackTrace();
	         }
		
		String []header=new String[]{"분야","도서번호","책 제목","저자","출판사","수정"};
		String [][]contents=new String[n][6];
		
		 int i=0;
		 try {
	         fr = new FileReader(f);
	         br2 = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
	         String readLine = null;
	         
	         while((readLine=br2.readLine())!=null) {   
	        	 StringTokenizer st=new StringTokenizer(readLine,"/");
	        	 for(int a=0;a<5;a++)
	        	   contents[i][a]=st.nextToken();
	           i++;
	         }  
		 }
	         catch(IOException e) {
	        	 e.printStackTrace();
	         }
		DefaultTableModel model=new DefaultTableModel(contents,header);
		table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 750, 300);
		add(scrollPane);
		
		scrollPane.setViewportView(table);
		table.getColumnModel().getColumn(5).setCellRenderer(new TableCell()); 
		table.getColumnModel().getColumn(5).setCellEditor(new TableCell()); 
	
		JButton back=new JButton("뒤로가기");
		back.setBounds(622, 351, 131, 38);
		back.setFont(new Font("굴림", Font.PLAIN, 23));
		add(back);
		
		
		/*setSize(800, 450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("도서 수정");
		setLocationRelativeTo(null);*/
		setVisible(true);
		
		/*back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				new PrintMenu();
			}
		});*/
	}
	
	class TableCell extends AbstractCellEditor implements TableCellEditor, TableCellRenderer{ 
	      JButton jb;
	      public TableCell() { 
	      jb = new JButton("수정"); 
	      jb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int index=table.getSelectedRow();
				new Editor_page(index);
				
			}
		});
	  }
	      
	   @Override 
	   public Object getCellEditorValue() { 
	      
	      return null; } 
	   @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) { 
	       
	      return jb; } 
	   @Override public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) { 
	      
	      return jb; 
	      } 
	   } 
	   }

public class Editor extends JFrame{
	public Editorpanel e1=null;
}

